package com.cyber57.keyboard

import android.inputmethodservice.InputMethodService
import android.graphics.Color
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputConnection
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class CyberKeyboardService : InputMethodService() {
    private fun keyButton(label: String, action: () -> Unit, weight: Float = 1f): Button {
        return Button(this).apply {
            text = label
            textSize = 20f
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                setColor(0xCC07130C.toInt())
                cornerRadius = 13f
                setStroke(1, 0xFF00E65C.toInt())
            }
            setPadding(2, 0, 2, 0)
            setOnClickListener { action() }
            layoutParams = LinearLayout.LayoutParams(0, dp(49), weight).apply {
                setMargins(dp(2), dp(3), dp(2), dp(3))
            }
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun commit(value: String) {
        currentInputConnection?.commitText(value, 1)
    }

    override fun onCreateInputView(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(5), dp(5), dp(5), dp(7))
            try {
                val bmp = assets.open("background.jpg").use { android.graphics.BitmapFactory.decodeStream(it) }
                background = BitmapDrawable(resources, android.graphics.Bitmap.createScaledBitmap(bmp, 900, 650, true)).apply {
                    alpha = 125
                }
            } catch (_: Exception) {
                setBackgroundColor(0xFF030805.toInt())
            }
        }

        val header = TextView(this).apply {
            text = "CYBER57  •  فارسی"
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(0xFF00FF66.toInt())
            setPadding(0, dp(2), 0, dp(4))
        }
        root.addView(header)

        val rows = listOf(
            listOf("ض","ص","ث","ق","ف","غ","ع","ه","خ","ح","ج"),
            listOf("ش","س","ی","ب","ل","ا","ت","ن","م","ک","گ"),
            listOf("ظ","ط","ز","ر","ذ","د","پ","و","چ")
        )
        rows.forEach { row ->
            val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
            row.forEach { ch -> line.addView(keyButton(ch, { commit("$ch'") })) }
            root.addView(line)
        }

        val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        bottom.addView(keyButton("؟", { commit("؟") }, 0.8f))
        bottom.addView(keyButton("،", { commit("،") }, 0.8f))
        bottom.addView(keyButton("فاصله", { commit(" ") }, 2.2f))
        bottom.addView(keyButton("⌫", {
            currentInputConnection?.deleteSurroundingText(1, 0)
        }, 0.9f))
        bottom.addView(keyButton("↵", { commit("\n") }, 0.9f))
        root.addView(bottom)
        return root
    }
}
