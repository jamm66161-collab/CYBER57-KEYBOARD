package com.cyber57.keyboard

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val base = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 32, 28, 32)
            setBackgroundColor(0xFF050A07.toInt())
        }
        val title = TextView(this).apply {
            text = "CYBER57 KEYBOARD"
            textSize = 25f
            gravity = Gravity.CENTER
            setTextColor(0xFF00FF66.toInt())
        }
        val info = TextView(this).apply {
            text = "کیبورد فارسی سایبری\nبرای استفاده، ابتدا فعالش کن و سپس آن را انتخاب کن."
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(0xFFE6FFE9.toInt())
            setPadding(0, 24, 0, 28)
        }
        val enable = Button(this).apply {
            text = "۱. فعال‌سازی کیبورد"
            setOnClickListener { startActivity(Intent("android.settings.INPUT_METHOD_SETTINGS")) }
        }
        val choose = Button(this).apply {
            text = "۲. انتخاب کیبورد"
            setOnClickListener {
                val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showInputMethodPicker()
            }
        }
        base.addView(title)
        base.addView(info)
        base.addView(enable)
        base.addView(choose)
        setContentView(base)
    }
}
